# Official TopUp Nepal

A starter full-stack gaming top-up store with:
- Mobile-friendly storefront
- Admin login at `/admin.html`
- SQLite product and order database
- Admin product management and order status controls
- eSewa ePay v2 and Khalti KPG-2 server-side checkout scaffolding
- Payment confirmation checked server-to-server before an order becomes `PAID`

## Run locally (Replit or computer)

1. Upload/extract this project into a Node.js Replit project.
2. Open the Shell and run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set `SESSION_SECRET` to a long random string and choose a strong `ADMIN_PASSWORD`.
5. Run `npm start`.
6. Open the web preview. Admin: `/admin.html`.

## Important setup before real money

- This is a starter build, not a live payment activation. Apply for eSewa and Khalti merchant accounts and use the credentials issued to your business.
- Add your deployed HTTPS domain to `BASE_URL` before enabling real gateway checkout.
- Set `ESEWA_ENV=production`, `ESEWA_PRODUCT_CODE`, and `ESEWA_SECRET_KEY` only after eSewa approves your merchant account.
- Set `KHALTI_ENV=production` and `KHALTI_SECRET_KEY` only after Khalti approves your merchant account.
- Never paste secret keys into browser code, screenshots, chat, or GitHub. Keep them only in Replit Secrets / environment variables.
- The code uses eSewa ePay v2 signed form plus status verification, and Khalti KPG-2 initiate plus lookup. Only a verified successful payment is marked `PAID`.
- Before launch, add HTTPS hosting, backups, privacy/terms/refund pages, order notifications, customer authentication, CSRF protection, monitoring, and provider-approved end-to-end sandbox tests.
- Orders are currently placed from a cart using the server-side product catalogue. Admin can manage product prices and review orders.
- Do not manually mark unpaid orders complete. Verify payment in the provider merchant portal first.

## Default catalogue
Seeded with the Free Fire diamond/membership prices from the current project draft. You can edit or add products in the admin panel.
