require('dotenv').config();
const express=require('express');
const helmet=require('helmet');
const rateLimit=require('express-rate-limit');
const session=require('express-session');
const SQLiteStore=require('connect-sqlite3')(session);
const Database=require('better-sqlite3');
const bcrypt=require('bcryptjs');
const crypto=require('crypto');
const path=require('path');
const fs=require('fs');

const app=express();
const PORT=Number(process.env.PORT||3000);
const BASE=process.env.BASE_URL||`http://localhost:${PORT}`;
const dbDir=path.join(__dirname,'data');fs.mkdirSync(dbDir,{recursive:true});
const db=new Database(path.join(dbDir,'shop.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,price INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,uid TEXT NOT NULL,player_name TEXT,payment TEXT NOT NULL,total INTEGER NOT NULL,status TEXT NOT NULL,items_json TEXT NOT NULL,provider_ref TEXT,transaction_ref TEXT,created_at TEXT NOT NULL);
`);
const count=db.prepare('SELECT COUNT(*) n FROM products').get().n;
if(!count){
 const seed=[
 ['25 Diamonds','Diamonds',35],['50 Diamonds','Diamonds',75],['115 Diamonds','Diamonds',110],['240 Diamonds','Diamonds',215],['355 Diamonds','Diamonds',320],['480 Diamonds','Diamonds',425],['610 Diamonds','Diamonds',540],['725 Diamonds','Diamonds',640],['850 Diamonds','Diamonds',750],['965 Diamonds','Diamonds',865],['1090 Diamonds','Diamonds',960],['1240 Diamonds','Diamonds',1060],['1480 Diamonds','Diamonds',1270],['1595 Diamonds','Diamonds',1375],['1720 Diamonds','Diamonds',1480],['1965 Diamonds','Diamonds',1690],['2090 Diamonds','Diamonds',1820],['2530 Diamonds','Diamonds',2130],['5060 Diamonds','Diamonds',4250],['7590 Diamonds','Diamonds',6370],['10120 Diamonds','Diamonds',8490],['Weekly Membership','Membership',220],['Weekly Lite','Membership',80],['Monthly Membership','Membership',1070]
 ];
 const ins=db.prepare('INSERT INTO products(id,name,category,price) VALUES(?,?,?,?)');
 for(const p of seed)ins.run(crypto.randomUUID(),...p);
}
if(!process.env.SESSION_SECRET||!process.env.ADMIN_PASSWORD){console.error('Set SESSION_SECRET and ADMIN_PASSWORD in .env before starting.');}
if(process.env.ADMIN_PASSWORD&&!db.prepare('SELECT id FROM admins WHERE username=?').get(process.env.ADMIN_USERNAME||'admin')){
 db.prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)').run(process.env.ADMIN_USERNAME||'admin',bcrypt.hashSync(process.env.ADMIN_PASSWORD,12));
}
app.set('trust proxy',1);
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'30kb'}));
app.use(session({store:new SQLiteStore({db:'sessions.sqlite',dir:dbDir}),secret:process.env.SESSION_SECRET||'change-this-secret',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000}}));
app.use(express.static(path.join(__dirname,'public')));
app.use('/api/',rateLimit({windowMs:60_000,limit:120,standardHeaders:true,legacyHeaders:false}));
const q=(sql)=>db.prepare(sql);
const admin=(req,res,next)=>req.session.adminId?next():res.status(401).json({error:'Admin login required'});
const money=n=>Math.round(Number(n));
function newId(prefix){return prefix+'-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase()}
function signEsewa(message,secret){return crypto.createHmac('sha256',secret).update(message).digest('base64')}
function esewaConfig(){return {code:process.env.ESEWA_PRODUCT_CODE,secret:process.env.ESEWA_SECRET_KEY,endpoint:process.env.ESEWA_ENV==='production'?'https://epay.esewa.com.np/api/epay/main/v2/form':'https://rc-epay.esewa.com.np/api/epay/main/v2/form',status:process.env.ESEWA_ENV==='production'?'https://esewa.com.np/api/epay/transaction/status/':'https://rc.esewa.com.np/api/epay/transaction/status/'}}
function khaltiBase(){return process.env.KHALTI_ENV==='production'?'https://khalti.com/api/v2':'https://dev.khalti.com/api/v2'}
async function verifyEsewa(order,ref){
 const c=esewaConfig();if(!c.code||!c.secret)throw Error('eSewa merchant credentials are not configured');
 const u=new URL(c.status);u.searchParams.set('product_code',c.code);u.searchParams.set('total_amount',String(order.total));u.searchParams.set('transaction_uuid',ref);
 const r=await fetch(u);const d=await r.json();return d.status==='COMPLETE';
}
async function verifyKhalti(pidx,order){
 if(!process.env.KHALTI_SECRET_KEY)throw Error('Khalti merchant key is not configured');
 const r=await fetch(khaltiBase()+'/epayment/lookup/',{method:'POST',headers:{Authorization:'Key '+process.env.KHALTI_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify({pidx})});
 const d=await r.json();return d.status==='Completed'&&Number(d.total_amount)===order.total*100;
}
app.get('/api/products',(req,res)=>res.json(q('SELECT id,name,category,price FROM products WHERE active=1 ORDER BY category,name').all()));
app.post('/api/orders',async(req,res)=>{
 try{
  const {items,uid,name,payment}=req.body||{};
  if(!Array.isArray(items)||!items.length||items.length>20||!String(uid||'').trim()||!['eSewa','Khalti'].includes(payment))return res.status(400).json({error:'Check items, player UID and payment method.'});
  const clean=[];let total=0;
  for(const it of items){const p=q('SELECT id,name,price FROM products WHERE name=? AND active=1').get(String(it.name||''));if(!p)return res.status(400).json({error:'A selected product is unavailable.'});clean.push({id:p.id,name:p.name,price:p.price});total+=p.price}
  const id=newId('OTN');const status='PENDING_PAYMENT';
  q('INSERT INTO orders(id,uid,player_name,payment,total,status,items_json,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,String(uid).trim(),String(name||''),payment,total,status,JSON.stringify(clean),new Date().toISOString());
  const order={id,total};
  if(payment==='eSewa'){
   const c=esewaConfig();if(!c.code||!c.secret)return res.status(503).json({error:'eSewa gateway is not configured. Add merchant credentials in .env.'});
   const fields={amount:String(total),tax_amount:'0',total_amount:String(total),transaction_uuid:id,product_code:c.code,product_service_charge:'0',product_delivery_charge:'0',success_url:BASE+'/api/payments/esewa/success',failure_url:BASE+'/api/payments/esewa/failure',signed_field_names:'total_amount,transaction_uuid,product_code'};
   fields.signature=signEsewa(`total_amount=${fields.total_amount},transaction_uuid=${id},product_code=${c.code}`,c.secret);
   return res.json({orderId:id,checkoutUrl:c.endpoint,method:'POST',fields});
  }
  if(!process.env.KHALTI_SECRET_KEY)return res.status(503).json({error:'Khalti gateway is not configured. Add merchant credentials in .env.'});
  const payload={return_url:BASE+'/api/payments/khalti/return',website_url:BASE,amount:total*100,purchase_order_id:id,purchase_order_name:'Official TopUp Nepal order '+id};
  const kr=await fetch(khaltiBase()+'/epayment/initiate/',{method:'POST',headers:{Authorization:'Key '+process.env.KHALTI_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const kd=await kr.json();if(!kr.ok||!kd.payment_url)throw Error(kd.detail||'Khalti could not start payment');
  q('UPDATE orders SET provider_ref=? WHERE id=?').run(kd.pidx,id);
  res.json({orderId:id,checkoutUrl:kd.payment_url});
 }catch(e){console.error(e);res.status(500).json({error:e.message||'Could not create order'})}
});
app.get('/api/payments/esewa/success',async(req,res)=>{
 try{
  if(!req.query.data)throw Error('Missing payment response');
  const payload=JSON.parse(Buffer.from(String(req.query.data),'base64').toString('utf8'));
  const order=q('SELECT * FROM orders WHERE id=?').get(payload.transaction_uuid);
  if(!order||Number(payload.total_amount)!==order.total)throw Error('Order or amount mismatch');
  const fields=String(payload.signed_field_names||'').split(',');
  const message=fields.map(k=>`${k}=${payload[k]}`).join(',');
  const expected=signEsewa(message,esewaConfig().secret);
  if(!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(String(payload.signature||''))))throw Error('Invalid eSewa signature');
  const paid=await verifyEsewa(order,payload.transaction_uuid);
  if(paid)q("UPDATE orders SET status='PAID',transaction_ref=? WHERE id=?").run(payload.transaction_code||'',order.id);
  res.redirect('/?payment='+(paid?'success':'pending'));
 }catch(e){console.error('eSewa callback:',e.message);res.redirect('/?payment=verification_failed')}
});
app.get('/api/payments/esewa/failure',(req,res)=>res.redirect('/?payment=failed'));
app.get('/api/payments/khalti/return',async(req,res)=>{
 try{
  const pidx=String(req.query.pidx||'');const id=String(req.query.purchase_order_id||'');
  const order=q('SELECT * FROM orders WHERE id=?').get(id);if(!order||!pidx)throw Error('Order not found');
  const paid=await verifyKhalti(pidx,order);
  if(paid)q("UPDATE orders SET status='PAID',transaction_ref=? WHERE id=?").run(String(req.query.transaction_id||''),id);
  else q("UPDATE orders SET status='PAYMENT_REVIEW' WHERE id=?").run(id);
  res.redirect('/?payment='+(paid?'success':'pending'));
 }catch(e){console.error('Khalti callback:',e.message);res.redirect('/?payment=verification_failed')}
});
app.post('/api/admin/login',rateLimit({windowMs:15*60_000,limit:8}),async(req,res)=>{
 const {username,password}=req.body||{};const a=q('SELECT * FROM admins WHERE username=?').get(String(username||''));
 if(!a||!bcrypt.compareSync(String(password||''),a.password_hash))return res.status(401).json({error:'Invalid username or password'});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Session error'});req.session.adminId=a.id;res.json({ok:true})});
});
app.get('/api/admin/me',admin,(req,res)=>res.json({ok:true}));
app.post('/api/admin/logout',admin,(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/admin/products',admin,(req,res)=>res.json(q('SELECT * FROM products ORDER BY category,name').all()));
app.post('/api/admin/products',admin,(req,res)=>{
 const {name,category,price}=req.body||{};const p=money(price);
 if(!String(name||'').trim()||String(name).length>90||!['Diamonds','Membership','Other'].includes(category)||!Number.isInteger(p)||p<1||p>1000000)return res.status(400).json({error:'Enter a valid name, category and price.'});
 const id=crypto.randomUUID();q('INSERT INTO products(id,name,category,price) VALUES(?,?,?,?)').run(id,String(name).trim(),category,p);res.json({id});
});
app.delete('/api/admin/products/:id',admin,(req,res)=>{q('UPDATE products SET active=0 WHERE id=?').run(req.params.id);res.json({ok:true})});
app.get('/api/admin/orders',admin,(req,res)=>res.json(q('SELECT * FROM orders ORDER BY created_at DESC LIMIT 500').all().map(o=>({...o,items:JSON.parse(o.items_json)}))));
app.patch('/api/admin/orders/:id',admin,(req,res)=>{
 const {status}=req.body||{};if(!['PROCESSING','COMPLETED','CANCELLED'].includes(status))return res.status(400).json({error:'Invalid order status'});
 const o=q('SELECT status FROM orders WHERE id=?').get(req.params.id);if(!o)return res.status(404).json({error:'Order not found'});
 if(status==='PROCESSING'&&o.status!=='PAID'&&o.status!=='PROCESSING')return res.status(400).json({error:'Only verified paid orders can be processed.'});
 if(status==='COMPLETED'&&o.status!=='PAID'&&o.status!=='PROCESSING')return res.status(400).json({error:'Do not complete an unpaid order. Verify payment first.'});
 q('UPDATE orders SET status=? WHERE id=?').run(status,req.params.id);res.json({ok:true});
});
app.get('/health',(req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log(`Official TopUp Nepal running on ${PORT}`));
